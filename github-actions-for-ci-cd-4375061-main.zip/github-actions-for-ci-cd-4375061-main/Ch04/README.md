# 4. Continuous Deployment Workflows
- [04_02_deploying_software_with_github_actions](./04_02_deploying_software_with_github_actions/README.md)
- [04_03_ci_cd_for_github_pages](./04_03_ci_cd_for_github_pages/README.md)
- [04_04_create_a_service_account](./04_04_create_a_service_account/README.md)
- [04_05_ci_cd_for_container_images](./04_05_ci_cd_for_container_images/README.md)
- [04_06_ci_cd_for_infrastructure_as_code](./04_06_ci_cd_for_infrastructure_as_code/README.md)
- [04_07_challenge_develop_a_deployment_pipeline](./04_07_challenge_develop_a_deployment_pipeline/README.md)
- [04_08_solution_develop_a_deployment_pipeline](./04_08_solution_develop_a_deployment_pipeline/README.md)
